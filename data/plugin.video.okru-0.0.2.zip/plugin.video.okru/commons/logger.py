import xbmc
import xbmcaddon
import xbmcgui
from commons import tools

__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')

def debug(message):
    log_enable = tools.getSettings("debug")
    if log_enable == "true":
        xbmc.log(__addonname__ + ":" + message)

def info(message=""):
    log_enable = tools.getSettings("debug")

    if log_enable == "true":
        xbmc.log(__addonname__ + ":" + message, xbmc.LOGINFO)
