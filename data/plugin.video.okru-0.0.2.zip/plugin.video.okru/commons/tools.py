import xbmcaddon

def getSettings(settingName):
    setting=xbmcaddon.Addon().getSetting(settingName)
    return setting